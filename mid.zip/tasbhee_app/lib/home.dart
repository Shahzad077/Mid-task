import 'package:flutter/material.dart';
import 'package:tasbeeh_counter/viewall.dart';
import 'package:tasbeeh_counter/counter.dart';
import 'newtasbeeh.dart';
import 'package:page_transition/page_transition.dart';


class home extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tasbeeh Generetor App'),
        backgroundColor: Colors.blue.shade900,
        elevation: 0,
      ),
      //drawer: MyDrawer(),
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.black,
                    backgroundImage: AssetImage('images/tasbeeh1.png'),
                  ),
                  // Text(
                  //   'Tasbeeh Counter',
                  //   style: Theme.of(context).textTheme.headline6,
                  // ),
                ],
              ),

              SizedBox.fromSize(
                size: Size(150,50),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 15,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1000)
                    ),
                  ),
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return myalertbox();
                        });
                  },
                  child: Text('Custom Tasbeeh',
                  style: TextStyle(
                    fontStyle: FontStyle.italic,
                    fontWeight: FontWeight.bold,
                  ),),
                ),
              ),

              SizedBox.fromSize(
                size: Size(150,50),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 15,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1000)
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      PageTransition(
                        type: PageTransitionType.fade,
                        child: CounterPage(),
                      ),
                    );
                  },
                  child: Text('Tasbeeh Counter',
                    style: TextStyle(
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.bold,
                    ),),
                ),
              ),

              SizedBox.fromSize(
                size: Size(150,50),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 15,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(1000)
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      PageTransition(
                        type: PageTransitionType.fade,
                        child: viewall(),
                      ),
                    );
                  },
                  child: Text('Saved Tasbeehs',
                    style: TextStyle(
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.bold,
                    ),),
                ),
              ),


            ]
        ),
      ),
    );
  }
}
