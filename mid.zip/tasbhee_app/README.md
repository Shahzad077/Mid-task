# tasbhee_app

A new Flutter project.

## Student_Info.

Name: Husn-e-Riasat

Reg no: sp19-bcs-011

Section: A

Batch: 18-BCS

Semester: 8


![Screenshot_2022-11-20-20-11-24-69_5365c9364b957f0d09a69abba9f7d850](https://user-images.githubusercontent.com/101085672/202910231-1d40f425-5eb8-4ed4-b2c4-8b743fe269d1.jpg)
![Screenshot_2022-11-20-20-11-32-20_5365c9364b957f0d09a69abba9f7d850](https://user-images.githubusercontent.com/101085672/202910300-10b5665d-137c-455e-a396-4ca54ea5bd47.jpg)
![Screenshot_2022-11-20-20-11-45-62_5365c9364b957f0d09a69abba9f7d850](https://user-images.githubusercontent.com/101085672/202910309-dcc9ef22-4bac-47e8-a6a6-961f5ff55bd2.jpg)
![Screenshot_2022-11-20-20-11-55-34_5365c9364b957f0d09a69abba9f7d850](https://user-images.githubusercontent.com/101085672/202910320-a276b81e-e94d-4412-99a2-834494329d2d.jpg)
![Screenshot_2022-11-20-20-12-07-98_5365c9364b957f0d09a69abba9f7d850](https://user-images.githubusercontent.com/101085672/202910332-417d15e6-497d-4bb0-9f93-3c66708ce248.jpg)
