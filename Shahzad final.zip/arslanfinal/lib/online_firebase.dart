import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class OnlineFirebase extends StatefulWidget {
  @override
  State<OnlineFirebase> createState() => _OnlineFirebaseState();
}

class _OnlineFirebaseState extends State<OnlineFirebase> {
  @override
  User? current = FirebaseAuth.instance.currentUser;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<dynamic> firebaselist = [];

  @override
  void initState() {
    super.initState();
    firebasedata();
    print(firebaselist);
  }

  void firebasedata() async {
    QuerySnapshot snapshot = await _firestore
        .collection("arslan")
        .doc(current?.uid)
        .collection('anwser')
        .get();
    setState(() {
      firebaselist = snapshot.docs.map((e) => e["ans"]).toList();
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.tealAccent.shade700,
        centerTitle: true,
        title: Text("Result"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('arslan')
            .doc(current?.uid)
            .collection('answer')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return CircularProgressIndicator();
          }
          List<dynamic> array = snapshot.data!.docs
              .map((document) => document.get('ans') as dynamic)
              .toList();
          return ListView.builder(
            itemCount: array.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  color: Colors.deepOrangeAccent.shade100,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Tries     R/W     option",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Colors.black),
                        ),
                      ),
                      for (int a = 0; a < array[index].length; a++)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            "Try  ${a}  ${array[index][a].toString()} ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.white),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
