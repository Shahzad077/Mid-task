import 'package:flutter/material.dart';
import 'package:untitled/play_game.dart';

import 'online_firebase.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.tealAccent.shade700,
        actions: <Widget>[],
        elevation: 0.0,
        title: Text("HOME"),
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => PlayGame()));
              },
              child: Container(
                color: Colors.black,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(
                    "Play Game",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 30),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => OnlineFirebase()));
              },
              child: Container(
                color: Colors.red.shade900,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(
                    "Show offline Result",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 30),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => OnlineFirebase()));
              },
              child: Container(
                color: Colors.deepPurple.shade900,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(
                    "Show online Result",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 30),
                  ),
                ),
              ),
            ),
          ],
          mainAxisAlignment: MainAxisAlignment.center,
        ),
      ),
    );
  }
}
