import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PlayGame extends StatefulWidget {
  @override
  _PlayGameState createState() => _PlayGameState();
}

class _PlayGameState extends State<PlayGame> {
  int? randomNumber;
  int? userGuess;
  int tries = 2;
  String? mesa;
  List<int> options = [];
  List<String> listadd = [];
  User? current = FirebaseAuth.instance.currentUser;
  void generateRandomNumber() {
    randomNumber = Random().nextInt(100) + 100;
  }

  void generateOptions() {
    options = <int>[];
    while (options.length < 3) {
      int option = Random().nextInt(100) + 100;
      if (!options.contains(option)) options.add(option);
    }
    options.shuffle();
  }

  checkGuess() {
    if (userGuess == randomNumber) {
      setState(() {
        mesa = "Correct";
        listadd.add("Correct $randomNumber");
      });
    } else if (tries! > 0) {
      setState(() {
        tries = tries - 1;
        listadd.add("Wrong $randomNumber");
        mesa = "Wrong. You have $tries tries left.";
      });
      print("Wrong. You have $tries tries left.");
    } else {
      mesa = "Sorry, you ran out of tries. The number was $randomNumber.";
      print("Sorry, you ran out of tries. The number was $randomNumber.");
    }
  }

  void resetGame() {
    generateRandomNumber();
    generateOptions();
    tries = 2;
  }

  @override
  void initState() {
    // TODO: implement initState
    generateRandomNumber();
    generateOptions();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.tealAccent.shade700,
        actions: <Widget>[],
        elevation: 0.0,
        title: Text("Play Game"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Container(
                  decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Guess the number between 100 and 200"),
                  )),
            ),
            MaterialButton(
              onPressed: () {
                setState(() {
                  userGuess = options[0];
                  checkGuess();
                });
              },
              child: Text(options[0].toString()),
            ),
            MaterialButton(
              onPressed: () {
                setState(() {
                  userGuess = options[1];
                  checkGuess();
                });
              },
              child: Text(options[1].toString()),
            ),
            MaterialButton(
              onPressed: () {
                setState(() {
                  userGuess = options[2];
                  checkGuess();
                });
              },
              child: Text(options[2].toString()),
            ),
            Center(
              child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(mesa ?? ""),
                  )),
            ),
            MaterialButton(
              highlightElevation: 0.0,
              elevation: 0.0,
              color: Colors.red,
              child: Text(
                "Generate Again Random Number",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 20),
              ),
              onPressed: () {
                setState(() {
                  resetGame();
                });
              },
            ),
            MaterialButton(
              highlightElevation: 0.0,
              elevation: 0.0,
              color: Colors.blueAccent,
              child: Text(
                "Add to Firebase",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 20),
              ),
              onPressed: () {
                var a = FirebaseFirestore.instance
                    .collection("arslan")
                    .doc(current?.uid)
                    .collection('answer')
                    .add({
                  "ans": listadd,
                });
                if (a != null) {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text("Data Saved"),
                        content: Text("Your data has been successfully saved."),
                        actions: <Widget>[
                          MaterialButton(
                            child: Text("OK"),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ],
                      );
                    },
                  );
                }
              },
            ),
            MaterialButton(
              highlightElevation: 0.0,
              elevation: 0.0,
              color: Colors.black,
              child: Text(
                "Add to SQflite",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 20),
              ),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text("Data Saved"),
                      content: Text("Your data has been successfully saved."),
                      actions: <Widget>[
                        MaterialButton(
                          child: Text("OK"),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                      ],
                    );
                  },
                );
              },
            )
          ],
        ),
      ),
    );
  }
}
